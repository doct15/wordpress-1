<?php
//add settings default value
$background_color = '#fafafa';

$header_background_color = '#ffffff';
$header_text_color = '#666666';
$header_link_normal = '#3d3d3d';
$header_link_hover = '#77cc6d';

$body_text_color = '#666666';
$body_headings_color = '#444444';
$body_link_normal = '#3d3d3d';
$body_link_hover = '#77cc6d';

$footer_background_color =  '#3d3d3d';
$footer_text_color =  '#888888';
$footer_headings_color = '#ffffff';
$footer_link_normal = '#77cc6d';
$footer_link_hover = '#ffffff';

$button_background_normal = '#77cc6d';
$button_background_hover = '#68B25F';
$button_text_normal =  '#ffffff';
$button_text_hover = '#ffffff';